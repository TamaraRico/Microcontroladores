# UART IR Chat

Implement an IR based chat
