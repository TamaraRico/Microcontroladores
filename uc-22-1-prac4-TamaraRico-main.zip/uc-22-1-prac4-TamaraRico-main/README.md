# UART Example

Example of basic operation of the UART peripheral. See course site for further details.